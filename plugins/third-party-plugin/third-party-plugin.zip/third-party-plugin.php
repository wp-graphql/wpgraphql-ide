<?php
/**
 * Plugin Name:       Third Party Plugin
 * License:           GPLv3 or later
 * Text Domain:       wpgraphql-ide
 * Version:           1.0.0-beta.1
 * Requires PHP:      7.4
 * Tested up to:      6.5
 */


if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

